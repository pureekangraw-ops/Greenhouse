# Greenhouse Hub V2 Zone2 source/build handoff

Source commit is recorded in release.json. No live integration or deploy is included.

Run in source/: npm run check; npm test; npm run evaluate:agents.
Optional esbuild0.25.12 is required to regenerate the demo; set BUILD_SOURCE_SHA to release.json sourceCommit and ESBUILD_MODULE to your installed module path, then npm run build:demo and npm run test:demo-routing.
For local browser checks install compatible Playwright/Chromium and run npm run check:ui. Optional PLAYWRIGHT_MODULE / CHROMIUM_EXECUTABLE_PATH / UI_TEST_FONT_PATH select local tools only.
The demo/ bundle deliberately disables privileged APIs; it is not the connected source runtime.
Hub and GO patches are separate proposals under source/docs/handoffs/hub-v2-greenhouse, pinned to their own canonical release bases. Do not apply them to unrelated/newer branches or configure a live binding without the owner-authority contract.
Historical binary screenshots are omitted locally; original upstream blobs are preserved.
